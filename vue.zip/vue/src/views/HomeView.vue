<script setup>
import TheWelcome from '../components/ChatBot.vue'
</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
