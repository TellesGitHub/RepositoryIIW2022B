<template>
    <div>
      <div v-if="showContext" class="contaier-context">
        <div class="containerInputInicial">
          <input
            type="text"
            placeholder="Write the context of the conversation with our bot. be specific!"
            v-model="promptInicial"
            class="inputUserInicial"
          />
          <button class="inputUserInicial" @click="handleContextSubmit">
            <i class="bi bi-send"></i>aoba
          </button>
        </div>
      </div>
  
      <div v-if="!showContext" class="container-form">
        <button id="recomecar" @click="reloadPage">Recomeçar?</button>
        <h1>Gemidinho your friend...</h1>
        <div class="response" v-show="responses.length > 0">
          <p v-for="(response, index) in responses" :key="index">{{ response }}</p>
        </div>
        <div class="containerInput">
          <input
            type="text"
            placeholder="Let's talk, my friend?"
            v-model="userInput"
            class="inputUser"
          />
          <button class="inputUser" @click="handleUserMessage">
            <i class="bi bi-send">aoba 2</i>
          </button>
        </div>
      </div>
    </div>
    
  </template>
  
  <script>
  export default {
    data() {
      return {
        promptInicial: "",
        userInput: "",
        responses: [],
        showContext: true,
      };
    },
    methods: {
      async handleContextSubmit() {
        if (this.promptInicial === "") {
          alert("O input não pode estar vazio!");
        } else {
          this.showContext = false;
        }
      },
      async handleUserMessage() {
        if (!this.userInput) {
          alert("A mensagem do usuário não pode estar vazia!");
          return;
        }
  
        try {
          const url = `http://localhost:3000/api/clientgemini?prompt=${encodeURIComponent(this.promptInicial + this.userInput)}`;
          const response = await fetch(url);
  
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
  
          const responseText = await response.text();
          this.responses.push(responseText);
  
          this.userInput = "";
          this.$nextTick(() => {
            this.$refs.userInput.focus();
          });
        } catch (error) {
          console.error('Error fetching data:', error);
          alert('Failed to fetch data from server.');
        }
      },
      reloadPage() {
        location.reload();
      },
    },
  };
  </script>
  
  <style scoped>
  /* O CSS original pode ser usado aqui, com ajustes conforme necessário */
  
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
  }
  
  body {
    height: 100vh;
    width: 100%;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #323232;
  }
  
  .inputUser:hover {
    opacity: 80%;
    transition: .5s;
  }
  
  .container-form {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-around;
    width: 90%;
    height: 90%;
    background-color: darkseagreen;
    border-radius: 0.5rem;
  }
  
  .container-form .response {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-width: 95%;
    height: 75%;
    border-radius: 0.5rem;
    margin-bottom: 10%;
    overflow-y: scroll;
  }
  
  .response p {
    position: relative;
    width: 75%;
    height: 10%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .container-form .inputUser {
    outline: none;
    border: none;
  }
  
  .container-form #inputButton {
    cursor: pointer;
    width: 3rem;
    height: 3rem;
    background-color: rgba(0, 0, 0, 0.3);
  }
  
  .container-form #inputButton i {
    font-size: 22px;
    font-weight: 900;
    color: white;
  }
  
  .container-form .containerInput {
    width: 100%;
    height: 20%;
    background-color: rgba(255, 255, 255, 0.1);
    position: absolute;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .container-form #userMessage {
    width: 80%;
    height: 3rem;
    padding: 20px;
    margin: 0;
    border-top-left-radius: 0.5rem;
    border-bottom-left-radius: 0.5rem;
  }
  
  .contaier-context {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 90%;
    height: 90%;
    background-color: darkseagreen;
    border-radius: 0.5rem;
  }
  
  .containerInputInicial {
    width: 100%;
    height: 20%;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .containerInputInicial #contextControl {
    width: 80%;
    height: 3rem;
    padding: 20px;
    margin: 0;
    border-top-left-radius: 0.5rem;
    border-bottom-left-radius: 0.5rem;
  }
  
  .containerInputInicial #inputButtonInical {
    cursor: pointer;
    width: 3rem;
    height: 3rem;
    background-color: rgba(0, 0, 0, 0.3);
  }
  
  .containerInputInicial #inputButtonInical i {
    font-size: 22px;
    font-weight: 900;
    color: white;
  }
  
  .containerInputInicial .inputUserInicial {
    border: none;
    outline: none;
  }
  
  #recomecar {
    padding: 10px;
    background-color: #323232;
    color: white;
    border-radius: 0.4rem;
    position: absolute;
    top: 0.3rem;
    left: 0.3rem;
    cursor: pointer;
    border: none;
  }
  
  #recomecar:hover {
    opacity: 80%;
    transition: .5s;
  }
  
  .inputUserInicial:hover {
    opacity: 80%;
    transition: .5s;
  }
  </style>
  