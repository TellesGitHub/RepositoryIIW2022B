// server.js

import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';

// Carregar variáveis de ambiente
dotenv.config();

const app = express();
const port = 3000;

// Middleware para lidar com JSON no corpo das requisições
app.use(bodyParser.json());

// Carregar a chave da API a partir de variáveis de ambiente
const API_KEY = process.env.GOOGLE_API_KEY;
const genAI = new GoogleGenerativeAI(API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
const promptInicial = 'Apenas Responda em ingles.';

app.get('/api/clientgemini', async (req, res) => {
  const prompt = req.query.prompt; // Obtém o prompt do parâmetro da query

  if (!prompt) {
    return res.status(400).send('Missing prompt parameter.');
  }

  try {
    const result = await model.generateContent(promptInicial + prompt);
    const text = result.response.candidates[0].content.parts[0].text;
    res.send(text);
  } catch (error) {
    console.error('Error generating response:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
